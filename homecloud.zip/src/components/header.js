import React, { useState, useEffect } from "react";
import PropTypes from "prop-types"
import { Link } from "gatsby";
import { StaticImage } from "gatsby-plugin-image";

import styled from "styled-components";

const Header = () => {
  const [open, setOpen] = useState(false)
  useEffect(() => {
  window.addEventListener('scroll', isSticky);
  return () => {
  window.removeEventListener('scroll', isSticky);
  };
  });
  const isSticky = (e) => {
  const header = document.querySelector('.header');
  const scrollTop = window.scrollY;
  scrollTop >= 100 ? header.classList.add('is-sticky') : header.classList.remove('is-sticky');
  };
  return (
  <Wrapper className="header">
     <Container>
        <LogoAndLinks>
           <Logo>
              <StaticImage src="../assets/images/home-logo.png" alt="" />
           </Logo>
           <Nav>
              <StyledBurger open={open} onClick={() =>
                 setOpen(!open)}>
                 <div />
                 <div />
                 <div />
              </StyledBurger>
              <Ul open={open}>
                 <li>
                    <Link href='#'>
                    How it Works</Link>
                 </li>
                 <li>
                    <Link href='#'>
                    Benefits</Link>
                 </li>
                 <li>
                    <Link href='#'>
                    What’s Included</Link>
                 </li>
                 <li>
                    <Link to="/">
                    Login</Link>
                 </li>
              </Ul>
           </Nav>
        </LogoAndLinks>
     </Container>
  </Wrapper>
  );
  };
  export default Header; 

const Wrapper = styled.div`
width: 100%;
position:fixed;
background: linear-gradient(180deg, rgba(0, 0, 0, 0.61) 0%, rgba(0, 0, 0, 0) 100%);
z-index:999;
@media (max-width: 767px) {
  position:inherit;
  display:inline-block;
  backgroud:none;
  background-color:rgba(0,0,0,.5);
}
`;
const Container = styled.div`
  max-width: 1230px;
  margin: 0 auto;
  padding: 0px 15px;
`;
const LogoAndLinks = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: stretch;
  height: 100%;
  padding:40px 0;
  @media (max-width: 767px) {
    padding:25px 0;
  }
`;
const Logo = styled.div`
  display: grid;
  place-items: center;
  @media (max-width: 359px) {
    width:180px;
  }
`;
const Nav = styled.nav`
  padding: 0 0px;
  display: flex;
  justify-content: end;
  z-index:999;
 `;
 const StyledBurger = styled.div`
  width: 2rem;
  height: 2rem;
  position: fixed;
  top:24px;
  right: 15px;
  z-index: 20;
  display: none;
  cursor: pointer;
  @media (max-width: 767px) {
    display: flex;
    justify-content: space-around;
    flex-flow: column nowrap;
  }
  div {
    width: 2rem;
    height: 0.25rem;
    background-color: ${({ open }) => open ? '#333D47' : '#333D47'};
    border-radius: 10px;
    transform-origin: 1px;
    transition: all 0.3s linear;
    &:nth-child(1) {
      transform: ${({ open }) => open ? 'rotate(45deg)' : 'rotate(0)'};
    }
    &:nth-child(2) {
      transform: ${({ open }) => open ? 'translateX(100%)' : 'translateX(0)'};
      opacity: ${({ open }) => open ? 0 : 1};
    }
    &:nth-child(3) {
      transform: ${({ open }) => open ? 'rotate(-45deg)' : 'rotate(0)'};
    }
  }
`;

const Ul = styled.ul`
  list-style: none;
  display: flex;
  flex-flow: row nowrap;
   @media (max-width: 767px) {
    flex-flow: column nowrap;
    background-color: #fff;
    position: fixed;
    transform: ${({ open }) => open ? 'translateX(0)' : 'translateX(100%)'};
    top: 0;
    right: 0;
    height: 100vh;
    width: 300px;
    padding-top: 3.5rem;
    transition: transform 0.3s ease-in-out;
    margin: 0;
  }
  @media (max-width: 360px) {
    width: 250px;
  }
  @media (min-width: 768px) {
li:last-child a{
  border:1px solid #fff;
  padding:8px 30px;
  border-radius:4px;
  margin-left: 20px;
}
}
  a {
    text-decoration: none;
    color: #fff;
    position: relative;
    padding: 0 20px;
    font-size:14px;
    font-weight:600;
    letter-spacing: -0.07875px;
    @media (max-width: 767px) {
      color: #333D47;
      margin-bottom:10px;
      display: inline-block;
    }
  }
`;

const Login = styled.div`

`;