import * as React from "react"
import styled from "styled-components";
import img from '../assets/images/hero-banner.jpg';

const Hero = () => {
  return(
  <Wrapper>
     <BannerText>
        <Container>
           <Text>
              <h2>Digitize your Home</h2>
              <p>We put your home information into an app to simplify maintenance and increase home value. When you’re ready to sell, your digital HomeCloud profile makes your home more marketable and data is seamlessly transferred to the next owner to set them up for success.</p>
              <Button>Digitize My Home</Button>
           </Text>
        </Container>
     </BannerText>
  </Wrapper>
  );
  };
export default Hero;
   
const Wrapper = styled.div`
background-image: url(${img});
background-position:center;
background-repeat:no-repeat;
background-size: cover;
min-height:800px;
position:relative;
@media (max-width: 767px) {
  min-height:300px;
  margin-bottom:180px;
}
`;
const Container = styled.div`
max-width: 1230px;
margin: 0 auto;
padding: 0 15px;
`;
const BannerText = styled.div`
position:absolute;
bottom:60px;
left:0;
right:0;
@media (max-width: 767px) {
  bottom:-150px;
}
`;
const Text = styled.div`
display: flex;
flex-direction: column;
padding:32px;
background: #FFFFFF;
box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.13);
border-radius: 6px;
width:460px;
@media (max-width: 767px) {
 margin:0 auto;
 padding:20px;
 width:90%;
}
@media (max-width: 479px) {
  width:85%;
}
h2{
  color: #236DDE;
  @media (max-width: 400px) {
    font-size:27px;
    line-height:32px;
    margin-bottom:15px;
  }
}
`;

const Button = styled.a`
background: #236DDE;
border-radius: 4px;
font-size: 16px;
line-height: 22px;
text-align: center;
letter-spacing: -0.09px;
color:#fff;
padding:17px 30px;
font-weight: 700;
`;
