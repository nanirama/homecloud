import { createGlobalStyle } from 'styled-components';
 
const GlobalStyle = createGlobalStyle`

body{margin:0;padding:0;font-family: 'Nunito Sans', sans-serif; font-weight:400;}
ul{ margin:0; padding:0;}
ul li{ list-style:none;float:left;}
a, a:hover{ text-decoration:none;}

h1,h2,h3,h4,h5,h6{font-family: 'Nunito Sans', sans-serif; margin:0;color: #333D47;font-weight:700;}
h2{font-size: 44px;line-height: 54px;letter-spacing: -0.91px;margin-bottom:24px;}
h3{font-size: 24px; line-height: 30px;letter-spacing: -0.24px;}
h4{font-size: 20px; line-height: 32px;letter-spacing: -0.12px;}
h5{font-size:18px;line-height: 23px;letter-spacing: -0.11px;}

p{font-family: 'Nunito Sans', sans-serif; margin:0;margin-bottom:24px;letter-spacing: -0.09px;font-size: 16px;line-height: 22px;letter-spacing: -0.09px;color: #333D47;}


.is-sticky {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 999;
  box-shadow: 0 2px 24px 0 rgb(0 0 0 / 15%);
  background-color: #ffffff !important;
  animation: 500ms ease-in-out 0s normal none 1 running fadeInDown;
  padding-top: 0px;
  padding-bottom: 0px;
}










@media only screen and (min-width:992px) and (max-width:1100px){
}
@media only screen and (max-width:767px){
  h2{font-size: 35px;line-height: 45px;}
}
@media only screen and (max-width:599px){

}
@media only screen and (max-width:479px){
p{font-size:15px;}
}


`;
 
export default GlobalStyle;